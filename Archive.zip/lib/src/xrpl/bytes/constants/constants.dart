class BinaryParserConst {}
