import 'package:xrpl_dart/src/exception/exception.dart';

class ASN1CodecException extends XRPLPluginException {
  const ASN1CodecException(super.message, {super.details});
}
