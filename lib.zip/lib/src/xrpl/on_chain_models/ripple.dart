enum NoRippleCheckRole {
  gateway("gateway"),
  user("user");

  final String value;
  const NoRippleCheckRole(this.value);
}
