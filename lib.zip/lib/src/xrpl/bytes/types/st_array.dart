part of 'package:xrp_dart/src/xrpl/bytes/serializer.dart';

class _StArrayConst {
  static const List<int> _arrayEndMarker = [0xF1];
  static const String _arrayEndMarkerName = 'ArrayEndMarker';
  static const List<int> _objectEndMarker = [0xE1];
}

class STArray extends SerializedType {
  STArray([super.buffer]);

  @override
  factory STArray.fromParser(BinaryParser parser, [int? lengthHint]) {
    final DynamicByteTracker bytestring = DynamicByteTracker();
    while (!parser.isEnd()) {
      var field = parser.readField();
      if (field.name == _StArrayConst._arrayEndMarkerName) {
        break;
      }
      bytestring.add(field.header.toBytes());
      bytestring.add(parser.readFieldValue(field)._buffer);
      bytestring.add(_StArrayConst._objectEndMarker);
    }
    bytestring.add(_StArrayConst._arrayEndMarker);
    return STArray(bytestring.toBytes());
  }

  @override
  factory STArray.fromValue(dynamic value) {
    if (value is! List) {
      throw XRPLBinaryCodecException('Invalid type to construct a STArray:'
          ' expected list, received ${value.runtimeType}.');
    }
    if (value.isNotEmpty && value[0] is! Map) {
      throw const XRPLBinaryCodecException(
          'Cannot construct STArray from a list of non-map objects');
    }
    final DynamicByteTracker bytestring = DynamicByteTracker();
    for (var obj in value) {
      var transaction = STObject.fromValue(obj);
      bytestring.add(transaction.toBytes());
    }
    bytestring.add(_StArrayConst._arrayEndMarker);
    return STArray(bytestring.toBytes());
  }

  @override
  List<dynamic> toJson() {
    List<dynamic> result = [];
    final BinaryParser parser = BinaryParser(_buffer);

    while (!parser.isEnd()) {
      var field = parser.readField();
      if (field.name == _StArrayConst._arrayEndMarkerName) {
        break;
      }

      var outer = <String, dynamic>{};
      outer[field.name] = STObject.fromParser(parser).toJson();
      result.add(outer);
    }
    return result;
  }
}
