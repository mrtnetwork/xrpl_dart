abstract class XRPLBase {
  /// Converts the object to a JSON representation.
  Map<String, dynamic> toJson();
}

abstract class XrplNestedModel extends XRPLBase {}
